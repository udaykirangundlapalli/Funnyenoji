# Funny-emoji-
Emoji Generator is a small web application that allows users to enter keywords, which are then used to generate sentences composed of related emoji characters. It's a playful way to create emoji-based sentences for various contexts.
